﻿app.controller("ComposeController", function ($scope, $http) {
    $scope.model = {};
    $scope.ViewModel = {};
    $scope.Detmodel = {};
    $scope.model.IsEdit = false;
    $scope.isCompleted = false;
    $scope.isClosed = false;
    $scope.model.txtSearch = "";
    $scope.BranchName = "";
    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }
   
    $scope.OnGridGroupComboBoxChange = function (e) {
        var valid = comboBoxClearInavlidEntry(e);
        if (!valid) {
            SetComboValue("GridGroupId", null);

        }
        $("#mainGrid").data("kendoGrid").dataSource.read();
    }

    $scope.OnGridBranchComboBoxChange = function (e) {
        debugger;
        var valid = comboBoxClearInavlidEntry(e);
        if (!valid) {
            SetComboValue("GridBranchId", null);
        }
        $("#mainGrid").data("kendoGrid").dataSource.read();
    }
    $scope.OnStatusComboBoxChange = function (e) {
        debugger;
        var valid = comboBoxClearInavlidEntry(e);
        if (!valid) {
            SetComboValue("StatusId", null);
        }
        $("#mainGrid").data("kendoGrid").dataSource.read();
    }



    $scope.mainGridOptions = {
        dataSource: {
            type: "json",
            transport: {
                read: {
                    url: baseUrl + "Compose/GetMessageHeader",
                    dataType: "json",
                },
                parameterMap: function (options, operation) {
                    debugger;
                    var opt = {};
                    opt = options;
                    opt.BranchId = getComobBoxValue("GridBranchId");
                    opt.GroupId=getComobBoxValue("GridGroupId");
                    opt.StatusId = getComobBoxValue("StatusId");
                    opt.Search = $scope.model.txtSearch;
                    return opt;
                },
            },
            schema:
                    {
                        model:
                        {
                            id: "Id",
                            fields: {

                            }
                        }
                    },

            serverPaging: true,
            schema: {
                data: function (response) {
                    if (response.Result) {
                        return JSON.parse(response.Result);
                    }
                    return [];
                },
                total: 'Total',

            }
        },

        sortable: {
            mode: "single",
            allowUnsort: true
        },


        pageable: { pageSize: GridPageSize, refresh: true },

        resizeable: true,
        scrollable: false,
        //dataBound: function () {
        //    this.expandRow(this.tbody.find("tr.k-master-row").first());
        //},
        //specify columns that you want to display   
        columns: [
               {
                   field: "Name",
                   title: "Subject",
                   width: "80px",
                   filterable: false,

               },
                 {
                     field: "GroupName",
                     title: "Group",
                     width: "80px",
                     filterable: false,

                 },
                 {
                     field: "BranchName",
                     title: "Branch",
                     width: "80px",
                     filterable: false,

                 },
                 

                  {
                      field: "messagetype",
                      title: "Type",
                      width: "80px",
                      filterable: false,

                  },
                   {
                       field: "createdby",
                       title: "Created By",
                       width: "80px",
                       filterable: false,

                   },
                   
                   {
                           field: "createddate", title: "Created Date", width: "80px",
                           type: "date",
                           format: "{0:dd-MMM-yyyy hh:mm tt}"
                   },
                   
              


           {
               template: "<a href='javascript:void(0);' class='btn-edit'  ng-click='ComposePopup(this,\"Edit\")'  data-toggle='tooltip' title='Edit'><i class='las la-pen'></i></a> &nbsp; <a href='javascript:void(0);' class='btn-delete' ng-click='deleteMessage(this)'  data-toggle='tooltip' title='Delete'><i class='las la-trash-alt'></i> <a href='javascript:void(0);' ng-click='countStatus(this)'  data-toggle='tooltip' title='Status' <i class='fas fa-question-circle'></i> </a></a>",
               width: "40px",
               title: "Action",
               headerAttributes: { style: "text-align:center;" },
               attributes: { style: "text-align:center;" },


           },

        ]
    };
    $scope.subgridOptions = function (dataItem) {
        return {
            dataSource: {
                type: "json",
                transport: {
                    read: {
                        url: baseUrl + "Compose/GetMessageDetails",
                        dataType: "json"
                    },
                    parameterMap: function (options, operation) {
                        debugger;
                        var opt = {};
                        opt = options;
                        opt.messageid = dataItem.Id;
                        return opt;
                    },
                },

                serverPaging: true,
                schema: {
                    data: function (response) {
                        if (response.Result) {
                            return JSON.parse(response.Result);
                        }
                        return [];
                    },
                    total: 'Total',

                }

            },
            scrollable: false,
            sortable: true,
            pageable: { pageSize: GridPageSize, refresh: true },
            toolbar: [
        {
            template: "<a href='javascript:void(0);' class='btn btn-primary-o btn-sm' id='actionButton' ng-click='ComposeDetailPopup(this,\"Add\")'  data-container='body' data-toggle='' title='Add'>Compose Message</a>  <a href='javascript:void(0);' class='btn btn-primary-o btn-sm' id='actionButton'     ng-click='OpenImportPopup(this)'  data-container='body' title='Add'>Import CSV</a>"


            

        }
            ],
            columns: [

          {
              field: "BranchName",
              title: "Branch",
              width: "80px",
              filterable: false,
          },
           {
               field: "EmployeeName",
               title: "Employee",
               width: "80px",
               filterable: false,
           },
           {
               field: "description",
               title: "Message",
               width: "80px",
               filterable: false,
           },
            {
                field: "reply",
                title: "Reply",
                width: "80px",
                filterable: false,
            },
           {
               field: "StatusName",
               title: "Status",
               width: "80px",
               filterable: false,
           },
           {
               field: "createdby",
               title: "Created By",
               width: "80px",
               filterable: false,
           },
           {
               field: "createddate", title: "Created Date", width: "80px",
               type: "date",
               format: "{0:dd-MMM-yyyy hh:mm tt}"
           },
           {
              
               template: "#  if (StatusName == 'Closed' ) { # <a href='javascript:void(0);' class='btn-edit'  ng-click='ComposeDetailPopup(this,\"Edit\")'  data-toggle='tooltip' title='Edit'><i class='las la-pen'></i></a> &nbsp; <a href='javascript:void(0);' class='btn-delete' ng-click='deleteMessageDetail(this)'  data-toggle='tooltip' title='Delete'><i class='las la-trash-alt'></i></a> &nbsp; <a href='javascript:void(0);' class='btn-edit'  ng-click='showPopup(this)'  data-toggle='tooltip'  title='View'><i class='las la-info-circle'></i></a>#} \
                   else { # <a href='javascript:void(0);' class='btn-edit'  ng-click='ComposeDetailPopup(this,\"Edit\")'  data-toggle='tooltip' title='Edit'><i class='las la-pen'></i></a> &nbsp; <a href='javascript:void(0);' class='btn-edit'  ng-click='showPopup(this)'  data-toggle='tooltip'  title='View'><i class='las la-info-circle'></i></a> #} \#",
               width: "40px",
               title: "Action",
               headerAttributes: { style: "text-align:center;" },
               attributes: { style: "text-align:center;" },

           },
          

            ]
        };
    };


    
 
    $scope.ComposePopup = function (e, type) {
        debugger
        $("span.k-tooltip-validation").hide();
        if (type == 'Add')
        {
              $scope.clearFields();
        }
        else
        {

        
            if (e.dataItem != null) {
                var dataItem = e.dataItem;
                if (dataItem) {
                    $scope.model.IsEdit = true;
                    $scope.model.Id = dataItem.Id;
                    $scope.model.messagetype = dataItem.messagetype;               
                    $scope.model.branch_id = dataItem.branch_id;
                    $scope.model.Subject = dataItem.Name;            
                    $scope.model.group_id = dataItem.group_id;             
                    if ($scope.model.messagetype == 'Branch') {
                        SetComboValue("BranchId", dataItem.branch_id);                  
                        $("#BranchId").data('kendoComboBox').dataSource.read();
                        $("#BranchId").data('kendoComboBox').value(dataItem.branch_id);                
                    }
                    if ($scope.model.messagetype == 'Group') {                   
                        $("#GroupId").data('kendoComboBox').dataSource.read();
                        $("#GroupId").data('kendoComboBox').value(dataItem.group_id);                   
                    }
                    $scope.model.BtnName = "Update";
                }
                else {
                    $scope.clearFields();
                }
            }
        }
        
        $scope.winOptions = {
            title: dataItem == null ? "Add (New)" : "Edit",
            // activate: $scope.activate
        }
        $scope.WinGroup.setOptions($scope.winOptions);
        $scope.WinGroup.open().center();

    };

    $scope.CheckButton=function(obj)
    {
        if (obj == 'Group') {
            $("#GroupId").data('kendoComboBox').dataSource.read();
            SetComboValue("GroupId", null);
            $scope.model.group_id = '';
           
        }
        else {
            SetComboValue("BranchId", null);
            $("#BranchId").data('kendoComboBox').dataSource.read();
            $scope.model.branch_id = '';
        }

    }
    $scope.ComposeDetailPopup=function(e,type)
    {
        debugger;
        if (type == 'Add') {
            $scope.Detmodel = {};
            $scope.Detmodel.Id = '';
            $scope.Detmodel.IsEdit = false;
            $scope.Detmodel.messageid = e.dataItem.Id;
            $scope.model.messagetype = e.dataItem.messagetype;
            $scope.Detmodel.messagetype = e.dataItem.messagetype;
            if ($scope.Detmodel.messagetype == 'Group')
            {
                $scope.Detmodel.groupOrBranch = e.dataItem.group_id;
            }
                else
            {
                $scope.Detmodel.groupOrBranch = e.dataItem.branch_id;
            }
            
            $scope.Detmodel.branchid = e.dataItem.branch_id;
            $("#DetBranchId").data('kendoComboBox').dataSource.read();
            $scope.Detmodel.employeeid = '';
            $scope.Detmodel.description ='';
            $scope.Detmodel.BtnName = "Submit";
            $scope.isCompleted = false;
            SetComboValue("DetBranchId", $scope.Detmodel.branchid);
            $("#DetBranchId").data('kendoComboBox').value($scope.Detmodel.branchid);
             //$scope.Detmodel.branch_id = e.dataItem.branch_id;
            $scope.Detmodel.group_id = e.dataItem.group_id;
            SetComboValue("DetBranchId", null);
         
            SetMultiSelectorValue("EmployeeIds", null);
        }

        else
        {
        
            if (e.dataItem != null) {
                var dataItem = e.dataItem;
                if (dataItem) {
                    $scope.Detmodel = {};
                    $scope.Detmodel.IsEdit = true;
                    $scope.Detmodel.Id = dataItem.Id;
                    $scope.Detmodel.messageid = dataItem.messageid;
                    $scope.model.messagetype = e.dataItem.messagetype;
                    $scope.Detmodel.messagetype = e.dataItem.messagetype;
                    if ($scope.Detmodel.messagetype == 'Group') {
                        $scope.Detmodel.groupOrBranch = e.dataItem.group_id;
                    }
                    else {
                        $scope.Detmodel.groupOrBranch = e.dataItem.branch_id;
                    }
                  
                   
                    $scope.Detmodel.BranchName = dataItem.BranchName;
                    $scope.Detmodel.EmployeeName = dataItem.EmployeeName;
                    $scope.Detmodel.description = dataItem.description;
                    $("#DetBranchId").data('kendoComboBox').dataSource.read();
                    $scope.Detmodel.branchid = dataItem.branchid;
                    $("#DetBranchId").data('kendoComboBox').value(dataItem.branchid);
                    if (dataItem.StatusName == 'Completed' || dataItem.StatusName == 'Closed')
                        $scope.isCompleted = true;
                    $("#EmployeeId").data('kendoComboBox').dataSource.read();                   
                    $("#EmployeeId").data('kendoComboBox').value(dataItem.employeeid);
                    $scope.Detmodel.employeeid = dataItem.employeeid;
                    $scope.Detmodel.BtnName = "Update";
                }
                else {
                    $scope.clearDetFields();
                }
            }
        }
         
        $scope.winOptions = {
            title: dataItem == null ? "Add (New)" : "Edit",         
        }
        $scope.WinDetGroup.setOptions($scope.winOptions);
        $scope.WinDetGroup.open().center();
    
    }
    $scope.clearFields = function () {      
        $scope.model.Id = '';
        $scope.model.IsEdit = false;
        $scope.model.messagetype = 'Branch'
        $scope.model.Subject ="";
        $scope.model.Description = "";
        $scope.model.group_id='';
        $scope.model.branch_id = '';
        if($scope.model.messagetype == 'Group')
        {
            $("#GroupId").data('kendoComboBox').dataSource.read();
            SetComboValue("GroupId", null);
        }
        else

        {
            SetComboValue("BranchId", null);
            $("#BranchId").data('kendoComboBox').dataSource.read();
         }
       
       
     
        $scope.model.BtnName = "Submit";

    }



    $scope.clearDetFields = function () {
        $scope.Detmodel.Id = '';
        $scope.Detmodel.IsEdit = false;
        $scope.Detmodel.messageid = e.dataItem.Id;
        $scope.Detmodel.branchid = '';
        $scope.Detmodel.employeeid = '';
        $scope.Detmodel.description = '';
        $scope.Detmodel.BtnName = "Submit";
      
        SetMultiSelectorValue("EmployeeIds", null);
        $scope.Detmodel.BtnName = "Submit";

    }


    $scope.CancelDetail = function (e) {
        $scope.WinDetGroup.close();
    };

    $scope.Cancel = function (e) {
        $scope.WinGroup.close();
    };

    $scope.GridGroupDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        placeholder: "Group",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: baseUrl + "Compose/GetGroup"
                }
            }
        },
        filter: "contains",
        suggest: true
    };


    $scope.GroupDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: baseUrl + "Compose/GetGroup"
                }
            }
        },
        filter: "contains",
        suggest: true
    };

    $scope.BranchDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        placeholder: "Branch",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: baseUrl + "Group/GetBranch"
                }
            }
        },
        filter: "contains",
        suggest: true
    };

    $scope.DetailBranchDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: function () { return baseUrl + "Group/GetDetailBranch?Type="+$scope.Detmodel.messagetype+"&Id="+$scope.Detmodel.groupOrBranch  }
                }
            }
        },
        filter: "contains",
        suggest: true,
    };


    $scope.EmployeeDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: function () { return baseUrl + "Group/GetEmployee?Id=" + $scope.Detmodel.branchid }
                }
            }
        },
        filter: "contains",
        suggest: true,

    };

    $scope.OnGroupComboBoxChange = function (e) {
        comboBoxClearInavlidEntry(e);
    }
   

    $scope.OnBranchDetComboBoxChange = function (e) {
        debugger;
        var valid = comboBoxClearInavlidEntry(e);
        if (!valid) {
            if ($scope.Detmodel.IsEdit) {
                $("#EmployeeId").data('kendoComboBox').dataSource.read();
                SetComboValue("EmployeeId", null);
            }
            else {
                $("#EmployeeIds").data('kendoMultiSelect').dataSource.read();

                SetMultiSelectorValue("EmployeeIds", null);
            }

        }
        else
            if ($scope.Detmodel.IsEdit) {
                SetComboValue("EmployeeId", null);
                $("#EmployeeId").data('kendoComboBox').dataSource.read();
            }
            else {
                SetMultiSelectorValue("EmployeeIds", null);
                $("#EmployeeIds").data('kendoMultiSelect').dataSource.read();
            }

    }
    $scope.OnBranchComboBoxChange = function (e) {
        debugger;
        var valid = comboBoxClearInavlidEntry(e);      
    }
    $scope.OnEmployeeComboBoxChange = function (e) {
        var valid = comboBoxClearInavlidEntry(e);
        if (!valid) {            
        
             SetComboValue("EmployeeId", null);
        }
    }
    

    $scope.OnEmployeeMultiComboBoxChange = function (e) {
        var valid = comboBoxClearInavlidEntry(e);
        if (!valid) {

           
            SetMultiSelectorValue("EmployeeIds", null);
        }
    }
    $scope.Save = function () {
        debugger
        if ($scope.validator.validate()) {
            $scope.ShowLoaderImg();
            var branchIds = '';
            var groupIds = '';
            $scope.Message = {};
          
                if ($scope.model.messagetype == 'Branch') {                  
                    branchIds = getComobBoxValue("BranchId");
 
                  
                }
                else
                {
                    groupIds = getComobBoxValue("GroupId");
                   

                }         
            $scope.Message.Id = $scope.model.Id;
            $scope.Message.messagetype = $scope.model.messagetype;          
            $scope.Message.Name = $scope.model.Subject;         
            $scope.Message.branch_id = branchIds;
            $scope.Message.group_id = groupIds;       

            $http({
                method: 'POST',
                url: baseUrl + 'Compose/SubmitInfo',
                data: $scope.Message,
            }).then(function (response) {
                debugger;
                $scope.HideLoaderImg();
               
                    $scope.WinGroup.close();
                    SetMessage('Save')
                    $("#mainGrid").data("kendoGrid").dataSource.read();
              

            }, function errorCallback(response) {
                $scope.HideLoaderImg();
                SetMessage('Error');

            });


        }
    }



    $scope.SaveDetail=function(e)
    {
        if ($scope.DetGroupValidator.validate()) {
            $scope.ShowLoaderImg();
            var branchIds = '';
            var empIds = '';
            $scope.MessageDetail = {};
            if (!$scope.Detmodel.IsEdit)
            {
                empIds = $("#EmployeeIds").data('kendoMultiSelect').value().toString();
            }
            else
            {
                empIds = getComobBoxValue("EmployeeId");
            }
          
            branchIds = getComobBoxValue("BranchId");

            $scope.MessageDetail.Id = $scope.Detmodel.Id;
            $scope.MessageDetail.messageid = $scope.Detmodel.messageid;
            $scope.MessageDetail.branch_id = $scope.Detmodel.branch_id;
            $scope.MessageDetail.group_id = $scope.Detmodel.group_id;
            $scope.MessageDetail.messagetype = $scope.Detmodel.messagetype;
            $scope.MessageDetail.Name = $scope.model.Subject;
            $scope.MessageDetail.branchid = branchIds;
            $scope.MessageDetail.description = $scope.Detmodel.description;
            $scope.MessageDetail.EmployeeIds = empIds;
            

            $http({
                method: 'POST',
                url: baseUrl + 'Compose/SubmitDetailInfo',
                data: $scope.MessageDetail,
            }).then(function (response) {
                debugger;
                $scope.HideLoaderImg();

                if (response.data == 'error') {
                    SetMessage('Error')
                }
                else if (response.data == 'exists') {
                    SetMessage('DataExist')
                }
                else {
                    $scope.WinDetGroup.close();
                    SetMessage('Save')
                    $("#childGrid").data("kendoGrid").dataSource.read();
                }


            }, function errorCallback(response) {
                $scope.HideLoaderImg();
                SetMessage('Error');

            });


        }
    }

    $scope.deleteMessage = function (e) {
        $scope.DeleteModel = {};
        var warnText = "Are you sure you want to delete this record?";
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                $scope.ShowLoaderImg();
                $scope.DeleteModel.Id = e.dataItem.Id;
                $http({
                    method: 'POST',
                    url: baseUrl + 'Compose/Delete',
                    data: $scope.DeleteModel,
                }).then(function (response) {
                    debugger;
                    $scope.HideLoaderImg();
                    if (response.data == 'dependency')
                    {
                        SetMessage('CantDelete')
                    }
                    else if (response.data == 'success') {
                        SetMessage('Delete')
                    }
                    else
                    {
                        SetMessage('Error');
                    }
                    $("#mainGrid").data("kendoGrid").dataSource.read();


                }, function errorCallback(response) {
                    $scope.HideLoaderImg();
                    SetMessage('Error');

                });
            }
        });
    }

    $scope.deleteMessageDetail = function (e) {
        $scope.DeleteModel = {};
        var warnText = "Are you sure you want to delete this record?";
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                $scope.ShowLoaderImg();
                $scope.DeleteModel.Id = e.dataItem.Id;
                $http({
                    method: 'POST',
                    url: baseUrl + 'Compose/DeleteMessageDetail',
                    data: $scope.DeleteModel,
                }).then(function (response) {
                    debugger;
                    $scope.HideLoaderImg()
                    SetMessage('Delete')
                    $("#childGrid").data("kendoGrid").dataSource.read();


                }, function errorCallback(response) {
                    $scope.HideLoaderImg();
                    SetMessage('Error');

                });
            }
        });
    }


    
    $scope.StatusDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        placeholder: "Status",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: baseUrl + "DashBoard/GetStatus"
                }
            }
        },       
        filter: "contains",
        suggest: true
    };
   

 
    $scope.GroupSearch = function (e) {
        $("#mainGrid").data("kendoGrid").dataSource.read();

    }



    $scope.GetAllReplies=function(e)
    {
        $scope.ShowLoaderImg();
        $http({
            method: 'GET',
            url: baseUrl + 'DashBoard/GetAllReplies?Id=' + $scope.ViewModel.MessageDetailId,

        }).then(function (response) {
            debugger;
            var result = [];
         
           
            if (response.data.length>0) {
                result.push({ MessageDetailId: $scope.ViewModel.MessageDetailId, Message: e.description, Reply: e.reply, CreatedBy: e.createdby, EmployeeName: e.EmployeeName });
                for (var i = 0; i < response.data.length; i++) {                 
                    result.push({ MessageDetailId: $scope.model.MessageDetailId, Message: response.data[i].Message, Reply: response.data[i].Reply, CreatedBy: e.createdby, EmployeeName: e.EmployeeName });
                    if (response.data.length -i == 1)
                    {
                        if (response.data[i].Reply == '' || response.data[i].Reply == null || response.data[i].Reply == undefined)
                        {
                            $scope.ViewModel.ShowButton = false;
                        }
                        else

                        {
                            $scope.ViewModel.ShowButton = true;
                        }
                    }
                }

            }
            else
            {
                if (e.reply == '' || e.reply == null || e.reply == undefined) {
                    $scope.ViewModel.ShowButton = false;
                }
                else {
                    $scope.ViewModel.ShowButton = true;
                }

                result.push({ MessageDetailId: $scope.ViewModel.MessageDetailId, Message: e.description, Reply: e.reply, CreatedBy: e.createdby, EmployeeName: e.EmployeeName });
               
            }
            $scope.details = result;
            if (e.StatusName == "Closed")
                $scope.isClosed = true;
            $scope.ViewModel.SendMessage = "";

           
            
            $scope.winOptions = {
                title: "View",
                // activate: $scope.activate
            }
            $scope.WinDashBoard.setOptions($scope.winOptions);
            $scope.WinDashBoard.open().center();
            $scope.HideLoaderImg();

        }, function errorCallback(response) {
            $scope.HideLoaderImg();
            SetMessage('Error');

        });
    }
   

    $scope.showPopup = function (e) {
        debugger       
        if (e.dataItem != null) {


            var dataItem = e.dataItem;
            if (dataItem) {
                $scope.ViewModel.MessageDetailId = dataItem.Id;
                $scope.ViewModel.description = dataItem.description;
                $scope.ViewModel.reply = dataItem.reply;
                $scope.ViewModel.createdby = dataItem.createdby;
                $scope.ViewModel.EmployeeName = dataItem.EmployeeName;
                $scope.GetAllReplies(dataItem);
                           
            }
           
        }
           

    };



    $scope.Reply = function (e) {
        if ($scope.ReplyValidator.validate()) {
            $scope.ShowLoaderImg();
            $scope.Message = {};
            $scope.Message.MessageDetailId = $scope.ViewModel.MessageDetailId;
            $scope.Message.SendMessage = $scope.ViewModel.SendMessage;
            $http({
                method: 'POST',
                url: baseUrl + 'DashBoard/SubmitReply',
                data: $scope.Message,
            }).then(function (response) {
                debugger;
               
                $scope.HideLoaderImg();
                 $scope.WinDashBoard.close();
             // $scope.WinDashBoard.close();   $scope.GetAllReplies($scope.ViewModel);
                //  SetMessage('Save')
                $("#childGrid").data("kendoGrid").dataSource.read();


            }, function errorCallback(response) {
               
                $scope.HideLoaderImg();
                SetMessage('Error');

            });

        }
    }


        $scope.countStatus = function (obj) {
         
            $scope.ShowLoaderImg();
            $http({
                method: 'POST',
                url: baseUrl + 'Compose/GetTotalStatus?Id=' + obj.dataItem.Id

            }).then(function (response) {
                $scope.ShowLoaderImg();
                var result = [];
                if (response.data) {
                    for (var i = 0; i < response.data.length; i++) {
                        result.push({ Name: response.data[i].name, Total: response.data[i].Total });
                    }

                }
                $scope.list = result;
                
                $scope.HideLoaderImg();
                $scope.WinStatus.open().center();
                // $scope.GetDashBoardDetails();
           

            }, function errorCallback(response) {
                $scope.HideLoaderImg();
            });


        }

    


        $scope.OpenImportPopup = function (e) {
            debugger;

            if (e.dataItem.messagetype == "Branch") {
                $("#file").val("");
                $scope.Text = "";
                $scope.ParentId = e.dataItem.Id;
                $scope.BranchName = e.dataItem.BranchName;
                $scope.ParentBranchId = e.dataItem.branch_id;


                $scope.winOptions = {
                    title: "Import",
                }
                $scope.ImportPopup.setOptions($scope.winOptions);
                $scope.ImportPopup.open().center();
            }
            else
            {
                WarnMessage("Import option is not available if the notification type is Group");
            }


        }


        $scope.CancelImport = function (e) {
            $scope.ImportPopup.close();
        }


        $scope.getFileDetails = function (e) {
            debugger;
            $scope.files = [];        
            $scope.$apply(function () {

                // STORE THE FILE OBJECT IN AN ARRAY.
                for (var i = 0; i < e.files.length; i++) {
                    $scope.files.push(e.files[i])
                }

            });
        };

        $scope.uploadFiles = function () {
            debugger;
           
            if ($scope.Text == "" || $scope.Text == undefined || $scope.Text == null) {
                WarnMessage("Message is required");
                return null;
            }
            else {
                $scope.ShowLoaderImg();
                //FILL FormData WITH FILE DETAILS.
                var data = new FormData();

                for (var i in $scope.files) {
                    data.append("uploadedFile", $scope.files[i]);
                }

                // ADD LISTENERS.
                var objXhr = new XMLHttpRequest();

                objXhr.onreadystatechange = function () {
                    debugger
                    // var res =  XMLHttpRequest.responseText;
                  
                    if (this.readyState == 4 && this.status == 200) {
                        $scope.HideLoaderImg();

                        if (objXhr.responseText == "uploaded") {
                            WarnMessage("CSV uploaded successfully.");
                            $("#childGrid").data("kendoGrid").dataSource.read();
                        }
                        else if (objXhr.responseText == "invalid") {
                            WarnMessage("Some of the records have been imported and some were trauncated because of invalid branch codes");
                            $("#childGrid").data("kendoGrid").dataSource.read();
                        }
                        else if (objXhr.responseText == "nofile")
                            WarnMessage("Please upload a CSV file");
                        else if (objXhr.responseText == "invalidFormat")
                            WarnMessage("Invalid file format");
                        else if (objXhr.responseText == "duplicate")
                            WarnMessage("All these records already exists");
                        else if (objXhr.responseText == "notupl")
                            WarnMessage("Invalid Employee code or uploaded employees do not belong to selected branch-"+ $scope.BranchName);
                        
                        else
                            WarnMessage("CSV upload failed !!");

                    }
                };


                objXhr.open("POST", baseUrl + '/Compose/FileUpload');
                objXhr.setRequestHeader('MessageId', $scope.ParentId);
                objXhr.setRequestHeader('Message', $scope.Text);
                objXhr.setRequestHeader('BranchId', $scope.ParentBranchId);
                   objXhr.send(data);
            }
        }






    
});